using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletscript : MonoBehaviour
{
    private int bounceCount = 0;
    public int maxBounces = 9; // Destroy after 9 bounces

    public GameManager manager;



    public float normalBulletSpeed = 15f;
    public Rigidbody2D rb;
    public void Start()
    {
        manager = FindObjectOfType<GameManager>();
        rb = GetComponent<Rigidbody2D>();
        SetStraightVelocity();
    }
    public void SetStraightVelocity()
    {
        rb.velocity = transform.right * normalBulletSpeed;
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        bounceCount++; // Increase bounce count when hitting something

        if (bounceCount >= maxBounces) // Destroy after max bounces
        {
            Destroy(gameObject);
            if (manager.bulletsUsed >= manager.maxBullets)
            {
                manager.ShowDefeatPanel();

            }
        }

        if (collision.gameObject.CompareTag("Enemy")) // Check if hit by bullet and not already dead
        {
            Debug.Log("hit");
            Die();
        }
    }
    void Die()
    {
        // isDead = true;  // Set isDead to true
        // animator.SetBool("isDead", true); // Activate death animation
        Debug.Log("Enemy is dead!");
    }

}
