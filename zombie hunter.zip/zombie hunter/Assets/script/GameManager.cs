using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
public class GameManager : MonoBehaviour
{
    public int totalZombies; // Set this to the total number of zombies in the scene
    public int bulletsUsed = 0;
    public int maxBullets = 5;
    public GameObject victoryPanel;
    public GameObject defeatPanel;
    public AudioSource bulletFireSound;
    public Collider2D collider;
    public bool isGameOver = false;
    public GameObject pausePanel; // Reference to the pause panel
    public bool isGamePaused = false;
    public GameObject pauseButton;
    public TMP_Text bulletText;

    private void Start()
    {
        victoryPanel.SetActive(false);
        defeatPanel.SetActive(false);
        UpdateBulletUI();
    }

    public void OnZombieKilled()
    {
        totalZombies--;
        // // CheckGameStatus();
        // if (totalZombies > 0)
        // {
        //     totalZombies--;
        //     Debug.Log("Zombie killed! Remaining: " + totalZombies);
        //     // CheckGameStatus();  // Check if the game is won
        //      StartCoroutine(CheckGameStatusAfterBulletsGone());
        // }
        // else
        // {
        //     Debug.LogWarning("Zombie count is already zero! Double trigger?");
        // }
        CheckGameStatus();
    }
  
    // public void OnBulletFired()
    // {
    //     if (isGameOver) return;

    //     if (bulletsUsed >= maxBullets)
    //     {
    //         return; // Stop firing if the maximum bullets are used
    //     }
    //     bulletsUsed++;
    //     UpdateBulletUI();

    //     if (bulletFireSound != null)
    //     {
    //         bulletFireSound.Play();
    //     }

    //     CheckGameStatus();
    // }
    //   public void OnBulletFired()
    // {
    //     if (isGameOver) return; // Prevent firing if the game is over

    //     if (bulletsUsed >= maxBullets) 
    //     {
    //         return; // Prevent firing after max bullets are used
    //     }

    //     bulletsUsed++;
    //     UpdateBulletUI();

    //     if (bulletFireSound != null)
    //     {
    //         bulletFireSound.Play();
    //     }

    //     // Check if game status needs to be updated after firing
    //     CheckGameStatus();
    // }
public void OnBulletFired()
{
    if (isGameOver) return;  // Prevent firing if game is over

    if (bulletsUsed >= maxBullets) 
    {
        return;  // Stop firing if max bullets are used
    }

    bulletsUsed++;  // Increment bullets used
    UpdateBulletUI();  // Update bullet UI in the game

    if (bulletFireSound != null)
    {
        bulletFireSound.Play();
    }

    CheckGameStatus();  // Check if the game status (win/loss) needs to be updated
}
    private void UpdateBulletUI()
    {
        if (bulletText != null)
        {
            bulletText.text = "Bullets: " + Mathf.Max(0, maxBullets - bulletsUsed);
        }
    }
   private void CheckGameStatus()
{
    if (totalZombies <= 0)
    {
        ShowVictoryPanel();  // Show victory panel when all zombies are killed
    }
    else if (bulletsUsed >= maxBullets) 
    {
        // Start the coroutine to show defeat panel after bullets disappear
        StartCoroutine(ShowDefeatPanelAfterBulletsGone());
        Debug.Log("Defeat check");
    }
}
  private IEnumerator ShowDefeatPanelAfterBulletsGone()
{
    // Wait until all bullets are destroyed (i.e., no active bullets in the scene)
    yield return new WaitUntil(() => GameObject.FindGameObjectsWithTag("bullet").Length == 0);

    // Check if there are still zombies left
    if (totalZombies > 0)
    {
        ShowDefeatPanel();  // Show defeat panel if zombies remain
    }
}

    private void ShowVictoryPanel()
    {
        bulletFireSound.Stop(); // Stop bullet fire sound
        victoryPanel.SetActive(true);
        Time.timeScale = 0f; // Pause the game
        // Debug.Log("victory panel");
        isGameOver = true; // Mark game as over
        DisablePauseButton();
    }
    public void ShowDefeatPanel()
    {
        bulletFireSound.Stop(); // Stop bullet fire sound
        defeatPanel.SetActive(true);
        Time.timeScale = 0f; // Pause the game
        // Debug.Log("defeat panel stop");
        isGameOver = true; // Mark game as over
        DisablePauseButton();
    }


    public void RestartGame()
    {
        Time.timeScale = 1f; // ✅ Resume the game (if it was paused)
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); // ✅ Reload current scene
    }
    //to go menu
    public void GoToMenu()
    {
        Time.timeScale = 1f; // Resume game time before switching scenes
        SceneManager.LoadScene("levelmenu"); // Replace with your menu scene name
    }


    private bool hasCollided = false; // Track first collision

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (hasCollided) return; // Ignore further collisions

        hasCollided = true; // Mark as collided
        // Debug.Log("Bullet hit: " + collision.gameObject.name);

        // Destroy the collider so it doesn't detect further collisions
        // Destroy(GetComponent<Collider2D>());


        // Optional: Destroy bullet after a delay
        Destroy(gameObject, 1f); // Bullet disappears after 1 second
    }
    void Update()
    {
        // Example: Pressing "Escape" to trigger pause and go to the pause scene
        if (Input.GetKeyDown(KeyCode.Escape) && !isGameOver)
        {
            PauseGame(); // Call to load pause scene
        }
    }

    // Method to load the pause scene when the pause button is pressed
    public void PauseGame()
    {
        pausePanel.SetActive(true);  // Show the pause panel
        Time.timeScale = 0f;  // Pause the game (freeze everything)
        isGamePaused = true;  // Set game state to paused
    }

    // Method to resume the game
    public void ResumeGame()
    {
        Time.timeScale = 1f;  // Resume the game
        // SceneManager.LoadScene("CurrentSceneName");  // Load the current scene again to resume the gamea
        pausePanel.SetActive(false);
        isGamePaused = false;
    }


    public void DisablePauseButton()
    {
        if (pauseButton != null)
        {
            pauseButton.SetActive(false); // Disable the pause button
        }
    }

}