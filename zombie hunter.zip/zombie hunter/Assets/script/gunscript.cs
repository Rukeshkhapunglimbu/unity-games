// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEngine.InputSystem;
// using UnityEngine.EventSystems;

// public class gunscript : MonoBehaviour
// {
//     // Start is called before the first frame update
//     public GameObject gun;
//     public GameObject bullet;
//     private GameObject bulletinst;
//     public Transform bulletSpawnPoint;
//     public Vector2 worldPosition;
//     public Vector2 direction;
//     private GameManager gameManager;

//     void Start()
//     {
//         // Debug.Log(gameObject.transform.position);
//         // Debug.Log(gun.transform.position);
//         gameManager = FindObjectOfType<GameManager>(); // Find GameManager in the scene

//     }

//     public void Update()
//     {
//         if (gameManager != null && gameManager.isGameOver) return;

//         HandleGunRotation();
//         HandleGunShooting();
//     }

//     // Update is called once per frame
//     public void HandleGunRotation()
//     {
//         worldPosition = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
//         direction = (worldPosition - (Vector2)gun.transform.position).normalized;
//         gun.transform.right = direction;

//     }

//     public void HandleGunShooting()
//     {
//         // Prevent shooting when game is paused, over, or clicking UI
//         if (gameManager.isGamePaused || gameManager.isGameOver || EventSystem.current.IsPointerOverGameObject())
//             return;
//         if (gameManager.bulletsUsed >= gameManager.maxBullets)
//             return;

//         if (Mouse.current.leftButton.wasPressedThisFrame)
//         {
//             // Spawn bullet
//             bulletinst = Instantiate(bullet, bulletSpawnPoint.position, gun.transform.rotation);
//             Debug.Log("Bullet spawned!");

//             // Notify GameManager about bullet fire
//             if (gameManager != null)
//             {
//                 gameManager.OnBulletFired();
//             }
//         }
//     }
// }
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;
// using UnityEngine.TouchPhase;

public class gunscript : MonoBehaviour
{
    public GameObject gun;
    public GameObject bullet;
    private GameObject bulletinst;
    public Transform bulletSpawnPoint;
    public Vector2 worldPosition;
    public Vector2 direction;
    private GameManager gameManager;

    void Start()
    {
        gameManager = FindObjectOfType<GameManager>(); // Find GameManager in the scene
    }

    void Update()
    {
        if (gameManager != null && gameManager.isGameOver) return;

        HandleGunRotation();
        HandleGunShooting();
    }

  public void HandleGunRotation()
{
    if (Input.touchCount > 0) // For mobile
    {
        Touch touch = Input.GetTouch(0);
        worldPosition = Camera.main.ScreenToWorldPoint(touch.position);
    }
    else if (Mouse.current != null) // For PC
    {
        worldPosition = Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
    }

    direction = (worldPosition - (Vector2)gun.transform.position).normalized;
    gun.transform.right = direction;
}

 public void HandleGunShooting()
{
    // Prevent shooting when game is paused, over, or clicking UI
    if (gameManager.isGamePaused || gameManager.isGameOver || EventSystem.current.IsPointerOverGameObject(0))
        return;
    if (gameManager.bulletsUsed >= gameManager.maxBullets)
        return;

    // Mobile Shooting (Detecting Tap)
    if (Input.touchCount > 0)
    {
        Touch touch = Input.GetTouch(0);
        if (touch.phase == UnityEngine.TouchPhase.Ended) // Fire when tap starts
        {
            ShootBullet();
        }
    }
    // PC Shooting (Mouse Click Release)
    else if (Input.GetMouseButtonUp(0))
    {
        ShootBullet();
    }
}

void ShootBullet()
{
    bulletinst = Instantiate(bullet, bulletSpawnPoint.position, gun.transform.rotation);
    Debug.Log("Bullet spawned!");

    // Notify GameManager about bullet fire
    if (gameManager != null)
    {
        gameManager.OnBulletFired();
    }
}

}
