using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class nextlevel : MonoBehaviour
{
    public void LoadNextLevel()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;  // Get current level index
        int nextSceneIndex = currentSceneIndex + 1; // Next level index

        if (nextSceneIndex < SceneManager.sceneCountInBuildSettings) // Check if next level exists
        {
            SceneManager.LoadScene(nextSceneIndex);  // Load next level
            Time.timeScale = 1f;
        }
        else
        {
            Debug.Log("No more levels!"); // If no more levels, show message
        }
    }
}
