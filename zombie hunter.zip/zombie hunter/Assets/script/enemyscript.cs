using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyscript : MonoBehaviour
{


    public Animator animator;
    private GameManager gameManager;

    private bool isDead = false; // Boolean to track if the enemy is dead

     Collider2D myCollider;

    void Start()
    {
        gameManager = FindObjectOfType<GameManager>(); // Find GameManager in the scene
        myCollider = GetComponent<Collider2D>();
        animator = GetComponent<Animator>();
        // Debug.Log("animation");
        animator.SetBool("isDead", false);
    }
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("bullet")) // Check if hit by bullet and not already dead
        {
            Debug.Log("hit");
            myCollider.enabled = false;
            Die();
        }
    }
    void Die()
    {
        isDead = true;  // Set isDead to true
        animator.SetBool("isDead", true); // Activate death animation
        Debug.Log("Enemy is dead!");

        if (gameManager != null)
        {
            gameManager.OnZombieKilled();
        }

    }
}